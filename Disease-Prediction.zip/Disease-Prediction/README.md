# Disease Prediction
 BE main project
 Software Requirement
    Windows/Linux
    Pycharm/spyder/atom

Programming Language
  pythom 3.7
  tkinter

Hardware Requirement
  i3 processor/AMD ryzen 5
  RAM 4GB

Process
  1.Clone the project from github or download all the files of project from drive.
  2.import project into ide(pycharm/spyder)
  3.change the path of csv file.
  4.check for all required libraries are installed.
  5.run the project.
